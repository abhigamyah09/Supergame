package com.gameassist

import android.util.Log

/**
 * Adaptive scaling system for dynamic game difficulty.
 *
 * Solves Challenge 3 (Dynamic Speed Scaling):
 * As game progresses (score increases), objects fall faster.
 * The scan window must expand vertically to give more reaction time.
 * Processing FPS must adapt to phone's thermal state.
 *
 * Also handles Problem 8 (Budget Phone Thermal Throttling).
 */
class AdaptiveScaler(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "AdaptiveScaler"
        private const val TARGET_FRAME_TIME_MS = 80L    // Target: process frame in <80ms
        private const val MAX_FRAME_TIME_MS = 150L        // If exceeded, start throttling
        private const val CRITICAL_FRAME_TIME_MS = 200L  // If exceeded, heavy throttling
    }

    // Current score (for difficulty scaling)
    private var currentScore: Int = 0

    // Frame timing for thermal monitoring
    private val frameTimes = mutableListOf<Long>()
    private val MAX_FRAME_HISTORY = 20

    // Current adaptive settings
    var scanTopRatio: Float = 0.60f     // Start: scan bottom 40% of screen
        private set
    var targetFps: Float = 12f           // Start: 12 FPS
        private set
    var frameSkipRate: Int = 0           // 0=none, 1=skip every other, 2=skip 2 of 3
        private set
    var scanStep: Int = 4                // Pixel skip step (higher = faster but less accurate)

    private var frameCount = 0

    /**
     * Record frame processing time for thermal monitoring.
     */
    fun recordFrameTime(timeMs: Long) {
        frameTimes.add(timeMs)
        if (frameTimes.size > MAX_FRAME_HISTORY) {
            frameTimes.removeAt(0)
        }
        frameCount++

        // Update adaptive settings every 10 frames
        if (frameCount % 10 == 0) {
            updateAdaptiveSettings()
        }
    }

    /**
     * Update score for difficulty-based scaling.
     */
    fun updateScore(newScore: Int) {
        currentScore = newScore
        updateScanWindow()
    }

    /**
     * Update scan window based on score/difficulty.
     * Challenge 3: Early game → bottom 40%, Late game → bottom 70%
     */
    private fun updateScanWindow() {
        scanTopRatio = when {
            currentScore < 5 -> 0.60f     // Scan bottom 40%
            currentScore < 10 -> 0.50f   // Scan bottom 50%
            currentScore < 20 -> 0.40f    // Scan bottom 60%
            currentScore < 35 -> 0.35f    // Scan bottom 65%
            else -> 0.30f                 // Scan bottom 70% (maximum)
        }
        Log.d(TAG, "Score=$currentScore, scanTopRatio=$scanTopRatio")
    }

    /**
     * Update adaptive settings based on thermal state (frame processing times).
     * Problem 8: Budget phone thermal throttling management.
     */
    private fun updateAdaptiveSettings() {
        if (frameTimes.isEmpty()) return

        val avgFrameTime = frameTimes.average()
        val maxFrameTime = frameTimes.maxOrNull() ?: 0L

        when {
            // Critical: phone is severely throttled
            maxFrameTime > CRITICAL_FRAME_TIME_MS -> {
                targetFps = 6f
                frameSkipRate = 2       // Skip 2 of every 3 frames
                scanStep = 6           // Scan every 6th pixel
                Log.w(TAG, "CRITICAL throttle: fps=6, skip=2, step=6 (maxFrame=${maxFrameTime}ms)")
            }

            // Overheating: reduce processing load
            maxFrameTime > MAX_FRAME_TIME_MS -> {
                targetFps = 8f
                frameSkipRate = 1       // Skip every other frame
                scanStep = 5           // Scan every 5th pixel
                Log.w(TAG, "Throttling: fps=8, skip=1, step=5 (maxFrame=${maxFrameTime}ms)")
            }

            // Running hot: slight reduction
            avgFrameTime > TARGET_FRAME_TIME_MS -> {
                targetFps = 10f
                frameSkipRate = 0
                scanStep = 5
                Log.d(TAG, "Warm: fps=10, skip=0, step=5 (avgFrame=${"%.0f".format(avgFrameTime)}ms)")
            }

            // Normal: full performance
            else -> {
                targetFps = 12f
                frameSkipRate = 0
                scanStep = 4
                Log.d(TAG, "Normal: fps=12, skip=0, step=4 (avgFrame=${"%.0f".format(avgFrameTime)}ms)")
            }
        }
    }

    /**
     * Check if current frame should be skipped (for thermal throttling).
     */
    fun shouldSkipFrame(): Boolean {
        if (frameSkipRate == 0) return false
        return frameCount % (frameSkipRate + 1) != 0
    }

    /**
     * Get current frame interval in ms based on target FPS.
     */
    fun getFrameIntervalMs(): Long {
        return (1000f / targetFps).toLong()
    }

    /**
     * Get estimated processing latency (for urgency calculations).
     */
    fun getEstimatedLatencyMs(): Long {
        return if (frameTimes.isNotEmpty()) {
            frameTimes.average().toLong()
        } else {
            TARGET_FRAME_TIME_MS
        }
    }

    /**
     * Force heavy throttling (called by RAM monitor when memory is low).
     */
    fun forceThrottle() {
        targetFps = 6f
        frameSkipRate = 2
        scanStep = 6
        Log.w(TAG, "FORCED throttle from RAM monitor")
    }

    fun reset() {
        currentScore = 0
        frameCount = 0
        frameTimes.clear()
        scanTopRatio = 0.60f
        targetFps = 12f
        frameSkipRate = 0
        scanStep = 4
    }
}
