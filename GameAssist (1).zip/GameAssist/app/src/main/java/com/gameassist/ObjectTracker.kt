package com.gameassist

import android.graphics.Rect
import android.util.Log
import com.gameassist.models.GameObject
import com.gameassist.models.ObjectType
import kotlin.math.abs

/**
 * Tracks game objects across frames for trajectory prediction.
 * Assigns unique IDs to objects and maintains position history.
 *
 * Critical for Challenge 2 (UFO diagonal trajectory prediction):
 * Stores position data across multiple frames to calculate velocity vectors.
 */
class ObjectTracker {

    companion object {
        private const val TAG = "ObjectTracker"
        private const val MAX_HISTORY = 10          // Keep last 10 positions
        private const val MAX_TRACKED_OBJECTS = 20
        private const val MATCH_DISTANCE = 150      // Max pixel distance to match same object
        private const val MIN_FRAMES_FOR_PREDICTION = 3  // Need at least 3 frames for trajectory
    }

    // Tracked object data
    data class TrackedObject(
        val id: Int,
        val type: ObjectType,
        val positions: MutableList<FramePosition>,
        var lastSeenFrame: Int,
        var isExpired: Boolean = false
    )

    data class FramePosition(
        val centerX: Int,
        val centerY: Int,
        val boundingBox: Rect,
        val frameNumber: Int,
        val timestamp: Long
    )

    private val trackedObjects = mutableListOf<TrackedObject>()
    private var nextId = 0
    private var frameCount = 0

    /**
     * Process a new frame's detected objects.
     * Matches them with previously tracked objects and updates positions.
     * Returns list of all currently active tracked objects with their IDs.
     */
    fun updateFrame(detectedObjects: List<GameObject>, timestamp: Long): List<GameObject> {
        frameCount++
        val matchedIds = mutableSetOf<Int>()

        // Reset expired flags
        trackedObjects.forEach { it.isExpired = false }

        // Match detected objects to existing tracked objects
        for (detected in detectedObjects) {
            val bestMatch = findBestMatch(detected)

            if (bestMatch != null) {
                // Update existing tracked object
                bestMatch.positions.add(
                    FramePosition(
                        centerX = detected.centerX,
                        centerY = detected.centerY,
                        boundingBox = detected.boundingBox,
                        frameNumber = frameCount,
                        timestamp = timestamp
                    )
                )
                bestMatch.lastSeenFrame = frameCount
                matchedIds.add(bestMatch.id)

                // Trim old positions
                while (bestMatch.positions.size > MAX_HISTORY) {
                    bestMatch.positions.removeAt(0)
                }

                // Update detected object with tracked ID
                Log.d(TAG, "Matched ${detected.type} #${bestMatch.id} at (${detected.centerX}, ${detected.centerY})")

            } else {
                // New object - create tracked entry
                if (trackedObjects.size < MAX_TRACKED_OBJECTS) {
                    val newId = nextId++
                    val tracked = TrackedObject(
                        id = newId,
                        type = detected.type,
                        positions = mutableListOf(
                            FramePosition(
                                centerX = detected.centerX,
                                centerY = detected.centerY,
                                boundingBox = detected.boundingBox,
                                frameNumber = frameCount,
                                timestamp = timestamp
                            )
                        ),
                        lastSeenFrame = frameCount
                    )
                    trackedObjects.add(tracked)
                    matchedIds.add(newId)
                    Log.d(TAG, "New ${detected.type} #$newId at (${detected.centerX}, ${detected.centerY})")
                }
            }
        }

        // Mark unmatched objects as expired
        for (tracked in trackedObjects) {
            if (tracked.id !in matchedIds) {
                tracked.isExpired = true
            }
        }

        // Remove objects not seen for 5+ frames
        trackedObjects.removeAll {
            it.isExpired && (frameCount - it.lastSeenFrame) > 5
        }

        // Return updated detected objects with tracked IDs
        return detectedObjects.map { detected ->
            val match = trackedObjects.find { tracked ->
                tracked.id in matchedIds &&
                tracked.type == detected.type &&
                tracked.positions.last().centerX == detected.centerX &&
                tracked.positions.last().centerY == detected.centerY
            }
            if (match != null) {
                detected.copy(trackedId = match.id)
            } else {
                detected
            }
        }
    }

    /**
     * Find the best matching tracked object for a newly detected object.
     * Uses distance-based matching with type constraint.
     */
    private fun findBestMatch(detected: GameObject): TrackedObject? {
        var bestMatch: TrackedObject? = null
        var bestDistance = MATCH_DISTANCE

        for (tracked in trackedObjects) {
            if (tracked.isExpired) continue
            if (tracked.type != detected.type) continue

            val lastPos = tracked.positions.last()
            val dx = abs(lastPos.centerX - detected.centerX)
            val dy = abs(lastPos.centerY - detected.centerY)
            val distance = dx + dy  // Manhattan distance (faster than Euclidean)

            if (distance < bestDistance) {
                bestDistance = distance
                bestMatch = tracked
            }
        }

        return bestMatch
    }

    /**
     * Get position history for a tracked object by ID.
     * Returns null if object not found or has too few frames.
     */
    fun getPositionHistory(trackedId: Int): List<FramePosition>? {
        return trackedObjects.find { it.id == trackedId }?.positions?.takeIf {
            it.size >= MIN_FRAMES_FOR_PREDICTION
        }
    }

    /**
     * Get position history for a tracked object by reference.
     */
    fun getPositionHistory(tracked: TrackedObject): List<FramePosition> {
        return tracked.positions
    }

    /**
     * Get all currently active UFO objects with their tracking data.
     */
    fun getActiveUFOs(): List<TrackedObject> {
        return trackedObjects.filter {
            it.type == ObjectType.UFO && !it.isExpired
        }
    }

    /**
     * Get tracked object by ID.
     */
    fun getTrackedObject(id: Int): TrackedObject? {
        return trackedObjects.find { it.id == id && !it.isExpired }
    }

    /**
     * Get all currently active threat objects (meteors + UFOs).
     */
    fun getActiveThreats(): List<TrackedObject> {
        return trackedObjects.filter {
            (it.type == ObjectType.METEOR || it.type == ObjectType.UFO) && !it.isExpired
        }
    }

    /**
     * Reset all tracking data (call when game restarts).
     */
    fun reset() {
        trackedObjects.clear()
        nextId = 0
        frameCount = 0
        Log.d(TAG, "Tracker reset")
    }
}
